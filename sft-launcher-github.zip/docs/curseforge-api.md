# CurseForge API Key 配置

下载中心支持从 CurseForge 下载 Mod 和资源包，但 CurseForge 要求每个调用者提供 **API Key**。

> 没有 API Key 也能使用启动器下载功能 —— Modrinth 平台完全开放、无需配置。

## 获取 CurseForge API Key（免费）

1. 打开 [CurseForge 控制台](https://console.curseforge.com/)，用 CurseForge 账号登录（无账号需先注册）
2. 进入「API Keys」页面
3. 点击「Generate API Key」
4. 复制生成的 key（一串很长的十六进制/字母混合字符串）

## 配置到启动器

1. 打开启动器，进入「设置」页
2. 找到「CurseForge API Key」输入框
3. 粘贴你的 key
4. 点击其他区域自动保存

保存后即可在「下载中心」选择 CurseForge 平台进行搜索和下载。

## 注意事项

- API Key 属于敏感信息，请勿公开分享
- CurseForge 有请求频率限制，大量搜索/下载时请适当间隔
- 部分文件（尤其涉及版权的）可能没有直接下载地址，届时启动器会提示
