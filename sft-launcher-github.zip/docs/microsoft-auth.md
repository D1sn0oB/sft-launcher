# 微软账号登录配置

启动器的微软登录使用 **OAuth 设备码流程**，需要一个 Azure 应用注册的 Client ID。

## 为什么需要配置？

微软账号登录（Xbox/Minecraft 正版登录）需要经过微软的 OAuth 授权。每个启动器需要有自己的 Azure 应用注册，否则微软不会放行登录请求。

## 获取 Client ID（免费，约 5 分钟）

1. 打开 [Azure 应用注册门户](https://portal.azure.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade)，登录你的微软账号
2. 点击「新注册」
   - 名称：随便填，如 `WorkBuddyMC Launcher`
   - 支持的账户类型：选「个人 Microsoft 账户」（或「任何组织目录中的账户和个人 Microsoft 账户」）
   - 重定向 URI：选「公共客户端/移动和桌面应用程序」，值填 `https://login.microsoftonline.com/common/oauth2/nativeclient`
   - 点「注册」
3. 注册完成后，记下「应用程序（客户端）ID」这一串 UUID
4. 在左侧「身份验证」页：
   - 勾选「将应用程序视为公共客户端」（Allow public client flows）为 **是**
   - 保存

## 配置到启动器

1. 打开启动器源码 `src/core/auth.py`
2. 找到 `MS_CLIENT_ID = "00000000-0000-0000-0000-000000000000"`
3. 替换为你刚获取的客户端 ID
4. 重新打包或运行

## 说明

- 设备码流程：启动器会生成一个「设备代码」，你在浏览器打开授权页输入后即完成登录，无需在启动器内输入密码。
- 登录成功后 token 会缓存在 `.mc-launcher/cache/microsoft_token.json`，下次启动自动复用。
- 出于安全，token 有有效期，过期后需重新登录（后续版本将支持自动刷新）。
