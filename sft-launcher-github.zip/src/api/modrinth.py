"""Modrinth API 客户端：搜索与下载 mod / 资源包。

Modrinth 提供开放 API（无需密钥），支持按 MC 版本和加载器筛选。
"""
from __future__ import annotations

from typing import Optional

from core.downloader import DownloadError, http_get_json, retry_download

API = "https://api.modrinth.com/v2"
HEADERS = {"User-Agent": "sft-launcher/0.1.0"}

# 加载器类型 -> Modrinth category
LOADER_MAP = {
    "fabric": "fabric",
    "forge": "forge",
    "quilt": "quilt",
    "neoforge": "neoforge",
    "原版": "vanilla",
}


class ModrinthError(Exception):
    pass


class ModrinthClient:
    """Modrinth 搜索与下载客户端。"""

    def __init__(self, timeout: float = 15.0):
        self.timeout = timeout

    # ---------- 搜索 ----------
    def search(self, query: str, project_type: str = "mod",
               mc_version: Optional[str] = None,
               loader: Optional[str] = None,
               limit: int = 20) -> list[dict]:
        """搜索项目。project_type: mod / resourcepack。

        返回 [{slug, title, description, downloads, icon_url, project_type}]
        """
        facets = []
        if project_type:
            facets.append([f"project_type:{project_type}"])
        if mc_version:
            facets.append([f"versions:{mc_version}"])
        if loader:
            cat = LOADER_MAP.get(loader.lower())
            if cat:
                facets.append([f"categories:{cat}"])
        import json as _json
        import urllib.parse
        params = {
            "query": query,
            "limit": limit,
            "facets": _json.dumps(facets),  # 必须是合法 JSON 字符串
        }
        qs = urllib.parse.urlencode(params)
        try:
            data = http_get_json(f"{API}/search?{qs}", timeout=self.timeout, headers=HEADERS)
        except DownloadError as e:
            raise ModrinthError(f"搜索失败：{e}")
        results = []
        for hit in data.get("hits", []):
            results.append({
                "slug": hit.get("slug"),
                "title": hit.get("title"),
                "description": hit.get("description", ""),
                "downloads": hit.get("downloads", 0),
                "icon_url": hit.get("icon_url"),
                "author": hit.get("author"),
                "project_type": hit.get("project_type"),
            })
        return results

    # ---------- 版本 ----------
    def get_versions(self, slug: str, mc_version: Optional[str] = None,
                     loader: Optional[str] = None) -> list[dict]:
        """获取项目的可用版本（按 MC 版本/加载器筛选）。

        返回 [{id, version_number, game_versions, loaders, files}]
        """
        params = {}
        if mc_version:
            import json as _json
            params["game_versions"] = _json.dumps([mc_version])
        if loader:
            import json as _json
            cat = LOADER_MAP.get(loader.lower())
            if cat:
                params["loaders"] = _json.dumps([cat])
        import urllib.parse
        qs = "?" + urllib.parse.urlencode(params) if params else ""
        try:
            return http_get_json(f"{API}/project/{slug}/version{qs}",
                                 timeout=self.timeout, headers=HEADERS)
        except DownloadError as e:
            raise ModrinthError(f"获取版本失败：{e}")

    def pick_best_file(self, slug: str, mc_version: str,
                       loader: Optional[str] = None) -> Optional[dict]:
        """选择最适合当前环境的一个文件。

        返回 {id, filename, url, size} 或 None。
        """
        versions = self.get_versions(slug, mc_version, loader)
        if not versions:
            return None
        for v in versions:
            for f in v.get("files", []):
                return {
                    "id": f.get("id"),
                    "filename": f.get("filename"),
                    "url": f.get("url"),
                    "size": f.get("size", 0),
                }
        return None

    # ---------- 下载 ----------
    def download_to(self, file: dict, dest_dir, progress=None) -> str:
        """下载文件到指定目录。返回保存的文件路径。"""
        from pathlib import Path
        dest_dir = Path(dest_dir)
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / file["filename"]
        retry_download(file["url"], dest, progress=progress)
        return str(dest)
