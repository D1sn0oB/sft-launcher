"""应用上下文：协调各核心模块的单例入口。"""
from __future__ import annotations

from .config import LauncherConfig
from .downloader import DownloadError, http_get, http_get_json, retry_download, sha1_hex
from .version import VersionManager
from .java_manager import JavaManager
from .launcher import GameLauncher, GameLaunchError
from .auth import offline_auth, MicrosoftAuth


class App:
    """启动器全局应用对象。"""

    def __init__(self, root=None):
        self.config = LauncherConfig(root)
        self.versions = VersionManager(self.config)
        self.java = JavaManager(self.config)
        self.launcher = GameLauncher(self.config)
        self.auth = MicrosoftAuth(self.config.cache_dir)

    # 便捷转发
    @property
    def instances(self):
        return self.config.instances
