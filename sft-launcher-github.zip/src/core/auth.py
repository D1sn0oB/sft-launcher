"""账号认证：离线账号 + 微软账号（OAuth 设备码流程）。

微软登录链路（四步）：
  1. 微软 OAuth 获取 access_token（设备码流程）
  2. 用 access_token 换 XBL 3.0 token
  3. 用 XBL token 换 XSTS token
  4. 用 XSTS token 换 Minecraft access_token + profile

注意：需要 Azure 应用注册的 Client ID。可自定义，
见 docs/microsoft-auth.md 中的注册说明。
"""
from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Optional

import requests

from .downloader import http_get_json

# Azure 应用 Client ID（设备码流程）
# 说明：正式发布时请替换为你自己的 Azure 应用注册 Client ID
MS_CLIENT_ID = "00000000-0000-0000-0000-000000000000"
MS_SCOPE = "XboxLive.signin offline_access"
AUTH_URL = "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode"
TOKEN_URL = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token"
XBL_URL = "https://user.auth.xboxlive.com/user/authenticate"
XSTS_URL = "https://xsts.auth.xboxlive.com/xsts/authorize"
MC_LOGIN_URL = "https://api.minecraftservices.com/authentication/login_with_xbox"
MC_PROFILE_URL = "https://api.minecraftservices.com/minecraft/profile"


class AuthError(Exception):
    pass


def offline_auth(username: str) -> dict:
    """生成离线账号信息。UUID 由用户名哈希派生，保证同一用户 UUID 稳定。"""
    derived = uuid.uuid5(uuid.NAMESPACE_DNS, f"offline:{username}")
    return {
        "type": "offline",
        "username": username,
        "uuid": str(derived),
        "access_token": "0",
    }


class MicrosoftAuth:
    """微软账号 OAuth（设备码流程）客户端。"""

    def __init__(self, cache_dir: Path):
        self.cache_dir = cache_dir
        self.token_file = cache_dir / "microsoft_token.json"

    # ---------- 已保存账号 ----------
    def has_saved_account(self) -> bool:
        return self.token_file.exists()

    def load_saved(self) -> Optional[dict]:
        if not self.token_file.exists():
            return None
        try:
            return json.loads(self.token_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return None

    def save_account(self, account: dict) -> None:
        self.token_file.parent.mkdir(parents=True, exist_ok=True)
        self.token_file.write_text(json.dumps(account, ensure_ascii=False, indent=2),
                                   encoding="utf-8")

    def logout(self) -> None:
        if self.token_file.exists():
            self.token_file.unlink()

    # ---------- 设备码流程 ----------
    def request_device_code(self) -> dict:
        """请求设备码，返回 {device_code, user_code, verification_uri, interval, expires_in}。"""
        resp = requests.post(AUTH_URL, data={
            "client_id": MS_CLIENT_ID,
            "scope": MS_SCOPE,
        }, timeout=30)
        resp.raise_for_status()
        return resp.json()

    def poll_token(self, device_code: str, interval: float = 5.0, timeout: float = 600) -> dict:
        """轮询用户是否完成授权，成功后返回微软 token 响应。"""
        import time
        elapsed = 0
        while elapsed < timeout:
            time.sleep(interval)
            elapsed += interval
            resp = requests.post(TOKEN_URL, data={
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                "client_id": MS_CLIENT_ID,
                "device_code": device_code,
            }, timeout=30)
            data = resp.json()
            if "access_token" in data:
                return data
            err = data.get("error")
            if err == "authorization_pending":
                continue
            if err == "slow_down":
                interval += 5
                continue
            if err in ("authorization_declined", "expired_token"):
                raise AuthError("用户取消或授权过期")
            raise AuthError(f"授权失败: {data.get('error_description', err)}")
        raise AuthError("授权超时")

    # ---------- 四步兑换 ----------
    def _xbl_token(self, access_token: str) -> str:
        data = http_get_json_post(XBL_URL, {
            "Properties": {
                "AuthMethod": "RPS",
                "SiteName": "user.auth.xboxlive.com",
                "RpsTicket": "d=" + access_token,
            },
            "RelyingParty": "http://auth.xboxlive.com",
            "TokenType": "JWT",
        })
        return data["Token"]

    def _xsts_token(self, xbl_token: str) -> str:
        data = http_get_json_post(XSTS_URL, {
            "Properties": {"SandboxId": "RETAIL", "UserTokens": [xbl_token]},
            "RelyingParty": "rp://api.minecraftservices.com/",
            "TokenType": "JWT",
        })
        return data["Token"]

    def _mc_token(self, xsts_token: str) -> dict:
        data = http_get_json_post(MC_LOGIN_URL, {"identityToken": "XBL3.0 x=" + xsts_token})
        return data  # {username, access_token, token_type, expires_in}

    def _mc_profile(self, mc_token: str) -> dict:
        return http_get_json(MC_PROFILE_URL, headers={"Authorization": "Bearer " + mc_token})

    # ---------- 完整登录 ----------
    def login_device_flow(self, device_code: dict) -> dict:
        """在用户已授权后，用 device_code 完成微软登录，返回 MC 账号信息。"""
        tokens = self.poll_token(device_code["device_code"])
        return self.finish_login(tokens["access_token"])

    def finish_login(self, ms_access_token: str) -> dict:
        """从微软 access_token 完成到 MC 账号的完整兑换。"""
        xbl = self._xbl_token(ms_access_token)
        xsts = self._xsts_token(xbl)
        mc = self._mc_token(xsts)
        profile = self._mc_profile(mc["access_token"])
        account = {
            "type": "microsoft",
            "username": profile.get("name", mc.get("username", "Steve")),
            "uuid": profile.get("id"),
            "access_token": mc["access_token"],
            "mc_expires_in": mc.get("expires_in"),
            "refresh_token": None,  # 需要 oauth refresh_token，暂用 access_token 直登
        }
        self.save_account(account)
        return account

    def refresh_account(self, account: dict) -> Optional[dict]:
        """尝试用已有账号刷新（简化：直接复用 access_token）。"""
        return account


def http_get_json_post(url: str, payload: dict, headers: Optional[dict] = None) -> dict:
    """POST JSON 并返回 JSON（用于 XBL/XSTS/MC 接口）。"""
    h = {"Content-Type": "application/json", "Accept": "application/json"}
    if headers:
        h.update(headers)
    resp = requests.post(url, json=payload, headers=h, timeout=30)
    resp.raise_for_status()
    return resp.json()
