"""版本 JSON 兼容性解析：库文件规则、参数替换等。

负责将 MC version JSON 中的 library 定义解析为具体的下载目标，
并根据当前系统规则判断该库是否需要加载。
"""
from __future__ import annotations

import platform
import re
from typing import Optional

_OS = platform.system().lower()  # windows / darwin / linux
_ARCH = platform.machine().lower()


def _rule_allows(rules: Optional[list]) -> bool:
    """根据 os rules 判断当前系统是否允许该库/参数。

    无 rules 时返回 True。
    """
    if not rules:
        return True
    allow = False
    for rule in rules:
        action = rule.get("action")
        os_rule = rule.get("os", {})
        # 架构匹配
        arch = os_rule.get("arch")
        if arch:
            arch_ok = ("64" in _ARCH) if arch == "x86" else (arch not in ("x86",))
            if arch == "x86" and "64" in _ARCH:
                continue
        os_name = os_rule.get("name")
        version_re = os_rule.get("version")
        os_ok = (os_name is None) or (os_name == _OS)
        if version_re and not re.search(version_re, platform.platform().lower()):
            os_ok = False
        if os_ok and (os_name is None or (arch and arch_ok) or not arch):
            matched = True
        else:
            matched = False
        if action == "allow":
            if matched:
                allow = True
        elif action == "disallow":
            if matched:
                allow = False
    return allow


def parse_library(raw: dict) -> Optional[tuple]:
    """将 version JSON 中的一条 library 解析为
    (name, path, url, sha1, size)；当前系统不适用、为 natives、或仅含 classifier 时返回 None。

    natives（包含平台的动态库）返回 None 交由单独处理。
    """
    if not _rule_allows(raw.get("rules")):
        return None
    if "natives" in raw:
        return None  # 由 natives 下载单独处理
    downloads = raw.get("downloads", {})
    artifact = downloads.get("artifact")
    name = raw.get("name", "")
    # 带 natives classifier 的库（LWJGL3 风格）由 natives 单独处理
    if "natives-" in name:
        return None
    if artifact and artifact.get("path"):
        return (
            name,
            artifact["path"],
            artifact.get("url", ""),
            artifact.get("sha1"),
            artifact.get("size", 0),
        )
    # 无 artifact 的库（老版本）通过 name 推导路径
    path = name_to_path(name)
    if not path:
        return None
    return (name, path, "", None, 0)


def name_to_path(name: str) -> Optional[str]:
    """把 maven 坐标 com.example:foo:1.0 转成相对路径。"""
    parts = name.split(":")
    if len(parts) < 3:
        return None
    group, artifact, version = parts[0], parts[1], parts[2]
    if "@" in version:
        version, ext = version.split("@", 1)
    else:
        ext = "jar"
    return f"{group.replace('.', '/')}/{artifact}/{version}/{artifact}-{version}.{ext}"


# ---------- natives ----------
def _platform_tag() -> str:
    """返回平台标识：windows / linux / osx。"""
    s = _OS
    if s == "darwin":
        return "osx"
    return s


def platform_classifier_name(raw: dict) -> Optional[str]:
    """返回当前平台对应的 natives classifier 文件名（用于下载）。

    支持两种格式：
    - 老风格（LWJGL2）：`natives` 字段 -> 平台 classifier 名
    - LWJGL3 风格：name 中形如 `artifact:natives-windows` 的 classifier
    返回 None 表示不是当前平台的 native 库。
    """
    # 老风格：natives 字段
    natives = raw.get("natives")
    if natives:
        key = _platform_tag()
        if "windows" in _OS and "x86" in _OS and "64" not in _ARCH:
            # 32位windows特殊处理
            pass
        classifier = natives.get(key)
        if classifier and "${arch}" in str(classifier):
            classifier = classifier.replace("${arch}", "64" if "64" in _ARCH else "32")
        return classifier
    # LWJGL3 风格：name 含 :natives-<platform>
    name = raw.get("name", "")
    marker = f"natives-{_platform_tag()}"
    if f":{marker}" in name or f":{marker}-" in name:
        # 需要匹配规则（如 arm64 vs x86）
        if not _rule_allows(raw.get("rules")):
            return None
        if "windows" in _OS:
            # 区分 windows-arm64
            if "arm64" in name and "aarch64" not in _ARCH:
                return None
            if "arm64" not in name and "aarch64" in _ARCH:
                return None
        elif "osx" in name and "darwin" not in _OS:
            return None
        return name.split(":", 3)[3]  # 得到 natives-windows
    return None


def native_download_info(raw: dict, base_url: str = "") -> Optional[tuple]:
    """返回 (下载url, 相对路径, sha1) 或 None（无 natives 或非本平台）。

    优先使用 downloads.classifiers[classifier]；否则从 name 推导。
    """
    cls = platform_classifier_name(raw)
    if not cls:
        return None
    classifiers = raw.get("downloads", {}).get("classifiers", {})
    if cls in classifiers:
        info = classifiers[cls]
        return (info.get("url") or base_url + info.get("path", ""),
                info.get("path"), info.get("sha1"))
    # 推导路径（LWJGL3 名字带 classifier）
    name = raw.get("name", "")
    if ":" in name and "natives" in name:
        parts = name.split(":")
        group, artifact = parts[0], parts[1]
        version = parts[2] if len(parts) >= 3 else ""
        if not version:
            return None
        group_path = group.replace(".", "/")
        path = f"{group_path}/{artifact}/{version}/{artifact}-{version}-{cls}.jar"
        return (base_url + path, path, None)
    return None
