"""启动器全局配置管理。

负责：
- 管理全局设置（下载源、Java 路径、账号信息等）
- 管理多实例数据（实例列表、每个实例的独立配置）
- 维护目录结构（versions / instances / libraries / java 等）

配置以 JSON 存储，路径：<根目录>/launcher.json
"""
from __future__ import annotations

import json
import os
import platform
from pathlib import Path
from typing import Any, Optional

APP_NAME = "SFT 启动器"
APP_VERSION = "0.1.0"

# 支持的下载源
SOURCES = {
    "mojang": {
        "label": "Mojang 官方源",
        "version_manifest": "https://launchermeta.mojang.com/mc/game/version_manifest_v2.json",
        "library_base": "https://libraries.minecraft.net/",
        "resource_base": "https://resources.download.minecraft.net/",
        "meta_base": None,  # 官方无独立的元数据服务器
    },
    "bmclapi": {
        "label": "BMCLAPI 国内镜像",
        "version_manifest": "https://bmclapi2.bangbang93.com/mc/game/version_manifest_v2.json",
        "library_base": "https://bmclapi2.bangbang93.com/maven/",
        "resource_base": "https://bmclapi2.bangbang93.com/assets/",
        "meta_base": "https://bmclapi2.bangbang93.com/meta/",
    },
}


def default_root() -> Path:
    """返回默认的启动器根目录（用户目录下的 .mc-launcher）。"""
    if platform.system() == "Windows":
        base = Path(os.environ.get("APPDATA", Path.home()))
        return base / ".mc-launcher"
    return Path.home() / ".mc-launcher"


class LauncherConfig:
    """启动器配置 + 实例数据的总入口。"""

    def __init__(self, root: Optional[Path] = None):
        self.root = Path(root) if root else default_root()
        self.config_file = self.root / "launcher.json"
        # 目录结构
        self.versions_dir = self.root / "versions"
        self.libraries_dir = self.root / "libraries"
        self.resources_dir = self.root / "resources"       # assets
        self.instances_dir = self.root / "instances"
        self.java_dir = self.root / "java"
        self.cache_dir = self.root / "cache"
        self.logs_dir = self.root / "logs"
        for d in (self.versions_dir, self.libraries_dir, self.resources_dir,
                  self.instances_dir, self.java_dir, self.cache_dir, self.logs_dir):
            d.mkdir(parents=True, exist_ok=True)

        # 全局设置
        self.settings: dict[str, Any] = {}
        # 实例列表：[{...}]
        self.instances: list[dict[str, Any]] = []
        self._load()

    # ---------- 持久化 ----------
    def _load(self) -> None:
        if self.config_file.exists():
            try:
                data = json.loads(self.config_file.read_text(encoding="utf-8"))
                self.settings = data.get("settings", {})
                self.instances = data.get("instances", [])
            except (json.JSONDecodeError, OSError):
                self.settings = {}
                self.instances = []
        else:
            self.settings = {}
            self.instances = []

    def save(self) -> None:
        self.config_file.parent.mkdir(parents=True, exist_ok=True)
        data = {"version": APP_VERSION, "settings": self.settings, "instances": self.instances}
        self.config_file.write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    # ---------- 全局设置 ----------
    def get_setting(self, key: str, default: Any = None) -> Any:
        return self.settings.get(key, default)

    def set_setting(self, key: str, value: Any) -> None:
        self.settings[key] = value
        self.save()

    @property
    def source(self) -> str:
        """当前下载源 key。"""
        return self.settings.get("source", "bmclapi")

    @property
    def source_config(self) -> dict:
        return SOURCES.get(self.source, SOURCES["bmclapi"])

    # ---------- 实例 ----------
    def all_instances(self) -> list[dict[str, Any]]:
        return self.instances

    def get_instance(self, inst_id: str) -> Optional[dict[str, Any]]:
        for inst in self.instances:
            if inst.get("id") == inst_id:
                return inst
        return None

    def add_instance(self, inst: dict[str, Any]) -> None:
        self.instances.append(inst)
        self.save()

    def update_instance(self, inst_id: str, **fields: Any) -> bool:
        inst = self.get_instance(inst_id)
        if not inst:
            return False
        inst.update(fields)
        self.save()
        return True

    def remove_instance(self, inst_id: str) -> bool:
        inst = self.get_instance(inst_id)
        if not inst:
            return False
        # 删除实例目录
        import shutil
        inst_dir = self.instances_dir / inst_id
        if inst_dir.exists():
            shutil.rmtree(inst_dir, ignore_errors=True)
        self.instances = [i for i in self.instances if i.get("id") != inst_id]
        self.save()
        return True

    # ---------- 实例目录 ----------
    def instance_dir(self, inst_id: str) -> Path:
        return self.instances_dir / inst_id

    def instance_game_dir(self, inst_id: str) -> Path:
        """每个实例的独立游戏目录（版本分离）。"""
        return self.instances_dir / inst_id / "game"

    # ---------- 便捷 ----------
    def next_instance_id(self) -> str:
        n = len(self.instances) + 1
        while any(i.get("id") == f"instance{n}" for i in self.instances):
            n += 1
        return f"instance{n}"


def new_instance(name: str, version_id: str, source: str) -> dict[str, Any]:
    """创建一个实例的默认数据结构。"""
    import uuid
    return {
        "id": "inst_" + uuid.uuid4().hex[:8],
        "name": name,
        "version": version_id,
        "loader": None,          # "fabric" / "forge" / None
        "loader_version": None,
        "java_path": None,       # 手动指定 Java
        "memory_mb": 2048,       # 分配内存
        "resolution": [1280, 720],
        "auth_type": "offline",  # offline / microsoft
        "username": "",
        "extra_args": [],
        "created": None,
    }
