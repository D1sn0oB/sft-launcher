"""下载引擎：负责网络请求、下载进度回调、重试等基础能力。"""
from __future__ import annotations

import hashlib
import io
import time
from pathlib import Path
from typing import Callable, Optional

import requests

# 进度回调：已下载字节, 总字节, 文件路径
ProgressCallback = Callable[[int, int, str], None]


class DownloadError(Exception):
    pass


def _headers() -> dict:
    return {
        "User-Agent": "SFTLauncher/0.1.0",
    }


def http_get(url: str, timeout: float = 30.0) -> bytes:
    try:
        resp = requests.get(url, headers=_headers(), timeout=timeout)
        resp.raise_for_status()
        return resp.content
    except requests.RequestException as e:
        raise DownloadError(f"请求失败 {url}: {e}") from e


def http_get_json(url: str, timeout: float = 30.0, headers: Optional[dict] = None):
    import json
    h = dict(_headers())
    if headers:
        h.update(headers)
    resp = requests.get(url, headers=h, timeout=timeout)
    resp.raise_for_status()
    return resp.json()


def sha1_hex(path: Path) -> Optional[str]:
    """计算文件 sha1；文件不存在返回 None。"""
    if not path.exists():
        return None
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 256), b""):
            h.update(chunk)
    return h.hexdigest()


def download_file(url: str, dest: Path, sha1: Optional[str] = None,
                  progress: Optional[ProgressCallback] = None) -> bool:
    """下载文件到 dest。若 sha1 匹配则跳过。返回 True 表示成功/已存在。"""
    dest.parent.mkdir(parents=True, exist_ok=True)
    if sha1 and sha1_hex(dest) == sha1:
        return True

    try:
        resp = requests.get(url, headers=_headers(), timeout=60, stream=True)
        resp.raise_for_status()
        total = int(resp.headers.get("Content-Length") or 0)
        written = 0
        tmp = dest.with_suffix(dest.suffix + ".part")
        with open(tmp, "wb") as f:
            for chunk in resp.iter_content(chunk_size=1024 * 128):
                if not chunk:
                    continue
                f.write(chunk)
                written += len(chunk)
                if progress:
                    progress(written, total, str(dest))
        tmp.replace(dest)
        if sha1 and sha1_hex(dest) != sha1:
            raise DownloadError(f"校验失败 {dest.name}")
        return True
    except requests.RequestException as e:
        raise DownloadError(f"下载失败 {dest.name}: {e}") from e


def retry_download(url: str, dest: Path, sha1: Optional[str] = None,
                   progress: Optional[ProgressCallback] = None,
                   retries: int = 3, delay: float = 1.0) -> bool:
    """带重试的下载。"""
    for attempt in range(retries):
        try:
            return download_file(url, dest, sha1, progress)
        except DownloadError:
            if attempt < retries - 1:
                time.sleep(delay)
                continue
            raise
    return False
