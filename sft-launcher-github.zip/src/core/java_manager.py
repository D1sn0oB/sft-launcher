"""Java 运行时管理：检测本机 Java、按版本需求选择、触发下载提示。

MC 版本与 Java 版本对应关系（简化）：
- 1.16 及以下（不含 1.16.5 某些）：Java 8
- 1.16.5 - 1.20.x：Java 17
- 1.20.5+：Java 21
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Optional

from .config import LauncherConfig


def java_major_version(path: str) -> Optional[int]:
    """检测给定 java 可执行文件的版本主号，失败返回 None。"""
    try:
        out = subprocess.run([path, "-version"], capture_output=True, text=True, timeout=10)
        text = (out.stdout + out.stderr)
        # 匹配 "version \"1.8.0_xxx\"" 或 "version \"17.0.x\""
        m = re.search(r'version\s+"([^"]+)"', text)
        if not m:
            return None
        ver = m.group(1)
        if ver.startswith("1."):
            return int(ver.split(".")[1])
        return int(ver.split(".")[0])
    except Exception:
        return None


def version_to_java(version_id: str) -> int:
    """根据 MC 版本返回推荐的 Java 主版本（启发式，供离线/无 JSON 时使用）。

    优先级：version JSON 的 javaVersion.majorVersion > 本启发式。
    """
    # 解析主版本号
    m = re.match(r"(\d+)(?:\.(\d+))?(?:\.(\d+))?", version_id)
    if not m:
        return 17
    major = int(m.group(1))
    minor = int(m.group(2) or 0)
    if major == 1:
        if minor <= 16:
            return 8
        elif minor == 17:
            return 16
        elif minor <= 20:
            return 17
        else:
            return 21
    else:  # 1.x+ 新命名，如 25.x / 26.x
        if major >= 26:
            return 25
        elif major >= 25:
            return 25
        return 17


class JavaManager:
    """负责查找可用的 Java。"""

    def __init__(self, config: LauncherConfig):
        self.config = config

    def find_java(self, prefer_version: Optional[int] = None) -> Optional[str]:
        """寻找一个可用的 Java 路径。优先匹配 prefer_version。"""
        candidates: list[str] = []

        # 1. 启动器自管理目录（自动下载的）
        candidates += [str(p) for p in self._bundled_javas()]

        # 2. 本机 JAVA_HOME
        jh = os.environ.get("JAVA_HOME")
        if jh:
            candidates.append(str(Path(jh) / ("bin/java.exe" if os.name == "nt" else "bin/java")))
            candidates.append(str(Path(jh) / ("bin/java" if os.name == "nt" else "bin/java")))

        # 3. PATH 中的 java
        which = shutil.which("java")
        if which:
            candidates.append(which)

        # 4. 常见安装路径（Windows）
        if os.name == "nt":
            pf = Path(os.environ.get("ProgramFiles", "C:/Program Files"))
            pf86 = Path(os.environ.get("ProgramFiles(x86)", "C:/Program Files (x86)"))
            for base in (pf / "Java", pf86 / "Java", pf / "Eclipse Adoptium",
                         pf86 / "Eclipse Adoptium", pf / "Microsoft", pf86 / "Microsoft"):
                if base.exists():
                    for sub in base.iterdir():
                        j = sub / "bin" / "java.exe"
                        if j.exists():
                            candidates.append(str(j))

        # 去重并检测版本
        seen = set()
        if prefer_version is not None:
            for c in candidates:
                if c in seen:
                    continue
                seen.add(c)
                if java_major_version(c) == prefer_version:
                    return c
        for c in candidates:
            if c in seen:
                continue
            seen.add(c)
            if java_major_version(c) is not None:
                return c
        return None

    def _bundled_javas(self) -> list[Path]:
        """启动器自管理的 Java 目录中的可执行文件。"""
        results = []
        java_root = self.config.java_dir
        if java_root.exists():
            for sub in java_root.iterdir():
                if sub.is_dir():
                    exe = sub / ("bin/java.exe" if os.name == "nt" else "bin/java")
                    if exe.exists():
                        results.append(exe)
        return results

    def has_any_java(self) -> bool:
        return self.find_java() is not None
