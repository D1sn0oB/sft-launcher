"""游戏启动：组装参数、启动进程、离线/微软账号。

启动参数组装逻辑遵循 MC 官方 version JSON 中的 arguments / minecraftArguments。
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Optional

from .config import LauncherConfig, new_instance
from .downloader import sha1_hex
from .java_manager import JavaManager, java_major_version, version_to_java
from .version import VersionManager


class GameLaunchError(Exception):
    pass


class GameLauncher:
    """负责将实例启动为 Minecraft 进程。"""

    def __init__(self, config: LauncherConfig):
        self.config = config
        self.vm = VersionManager(config)
        self.jm = JavaManager(config)

    # ---------- 启动主入口 ----------
    def launch(self, instance: dict, auth: dict) -> subprocess.Popen:
        """启动游戏。auth 包含账号信息（offline/microsoft）。

        auth: {"type": "offline"|"microsoft", "username": "...", "uuid": "...", "access_token": "..."}
        """
        version_id = instance["version"]
        vjson = self.vm.get_version_json(version_id)

        # 确保版本已下载
        if not self.vm.version_files_present(version_id):
            raise GameLaunchError("游戏版本未下载完成，请先下载")

        # 选择 Java
        java_exe = instance.get("java_path")
        if not java_exe:
            # 优先使用 version JSON 的权威 javaVersion，否则用启发式
            jv = vjson.get("javaVersion")
            prefer = jv.get("majorVersion") if jv else version_to_java(version_id)
            java_exe = self.jm.find_java(prefer)
        if not java_exe:
            raise GameLaunchError("未找到可用的 Java，请在设置中指定 Java 路径或下载 Java")

        # 组装启动命令
        cmd = self._build_command(instance, vjson, java_exe, auth)
        game_dir = self.config.instance_game_dir(instance["id"])
        game_dir.mkdir(parents=True, exist_ok=True)

        # 写日志
        log_path = self.config.logs_dir / f"{instance['id']}.log"
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("\n===== 启动 " + instance["name"] + " =====\n")
            f.write(" ".join(cmd) + "\n")

        kwargs = {}
        if os.name == "nt":
            kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0
        proc = subprocess.Popen(
            cmd, cwd=str(game_dir),
            stdout=open(log_path, "a", encoding="utf-8", errors="replace"),
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            **kwargs,
        )
        return proc

    # ---------- 组装命令 ----------
    def _build_command(self, instance: dict, vjson: dict, java_exe: str, auth: dict) -> list[str]:
        game_dir = self.config.instance_game_dir(instance["id"])
        version_id = instance["version"]

        classpath = self._build_classpath(instance, vjson)
        mem = int(instance.get("memory_mb", 2048))
        res_w, res_h = instance.get("resolution", [1280, 720])
        user = auth.get("username", "Steve")
        uuid = auth.get("uuid", "00000000-0000-0000-0000-000000000000")
        access_token = auth.get("access_token", "0")
        auth_type = auth.get("type", "offline")

        # 基础 java 参数
        base = [
            java_exe,
            f"-Xms{mem}M",
            f"-Xmx{mem}M",
            "-Djava.library.path=" + str(self._natives_path(instance, vjson)),
            "-Dminecraft.launcher.brand=sftlauncher",
            "-Dminecraft.launcher.version=0.1.0",
        ]

        # 从 version json 取 arguments / minecraftArguments
        tail: list[str] = []
        arguments = vjson.get("arguments")
        if arguments and "game" in arguments:
            tail = self._expand_args(arguments["game"], instance, vjson, auth)
        else:
            # 老版本：minecraftArguments
            legacy = vjson.get("minecraftArguments")
            if legacy:
                tail = self._expand_legacy(legacy, game_dir, version_id, user, uuid,
                                           access_token, res_w, res_h)

        full = base + self._clean_tail(tail)
        return [str(x) for x in full]

    @staticmethod
    def _clean_tail(tail: list[str]) -> list[str]:
        """清理孤立的快速启动（quickPlay）参数：删除丢失了值的 --quickPlay* 标志。"""
        cleaned: list[str] = []
        skip_next = False
        for arg in tail:
            if skip_next:
                skip_next = False
                continue
            if arg.startswith("--quickPlay"):
                skip_next = True  # 跳过该 flag 及紧随其后的值
                continue
            cleaned.append(arg)
        return cleaned

    def _expand_args(self, args: list, instance: dict, vjson: dict, auth: dict) -> list[str]:
        """展开新版 arguments.game 中的规则和变量。"""
        game_dir = self.config.instance_game_dir(instance["id"])
        version_id = instance["version"]
        user = auth.get("username", "Steve")
        uuid = auth.get("uuid", "00000000-0000-0000-0000-000000000000")
        access_token = auth.get("access_token", "0")
        res_w, res_h = instance.get("resolution", [1280, 720])

        result: list[str] = []
        for item in args:
            if isinstance(item, str):
                expanded = self._substitute(item, game_dir, version_id, user, uuid,
                                            access_token, res_w, res_h)
                if self._is_resolved(expanded):
                    result.append(expanded)
            elif isinstance(item, dict):
                # 带规则的对象：只展开适用的
                rules = item.get("rules")
                if rules and not self._rules_allow(rules):
                    continue
                values = item.get("value")
                if isinstance(values, str):
                    values = [values]
                for val in values or []:
                    expanded = self._substitute(val, game_dir, version_id, user, uuid,
                                                access_token, res_w, res_h)
                    if self._is_resolved(expanded):
                        result.append(expanded)
        return result

    @staticmethod
    def _is_resolved(s: str) -> bool:
        """含未替换占位符的参数（如 ${quickPlayPath}）不传给游戏。"""
        return "${" not in s

    def _substitute(self, s: str, game_dir, version_id, user, uuid, access_token, w, h) -> str:
        reps = {
            "${version_name}": version_id,
            "${version_type}": "release",
            "${game_directory}": str(game_dir),
            "${assets_root}": str(self.config.resources_dir),
            "${assets_index_name}": self._asset_index_name(version_id),
            "${auth_player_name}": user,
            "${auth_session}": "token:" + access_token + ":" + uuid,
            "${auth_access_token}": access_token,
            "${auth_uuid}": uuid,
            "${clientid}": "00000000-0000-0000-0000-000000000000",
            "${resolution_width}": str(w),
            "${resolution_height}": str(h),
            "${user_type}": "legacy",
            "${user_properties}": "{}",
            "${version_type}": "release",
            "${natives_directory}": str(self._natives_path_for(version_id)),
            "${classpath_separator}": os.pathsep,
            "${auth_xuid}": "0",
            "${launcher_name}": "sftlauncher",
            "${launcher_version}": "0.1.0",
        }
        for k, v in reps.items():
            s = s.replace(k, v)
        return s

    def _expand_legacy(self, legacy: str, game_dir, version_id, user, uuid, access_token, w, h) -> list[str]:
        s = self._substitute(legacy, game_dir, version_id, user, uuid, access_token, w, h)
        # 拆分成参数
        return s.split()

    def _rules_allow(self, rules: list) -> bool:
        from .compat import _rule_allows
        return _rule_allows(rules)

    # ---------- classpath ----------
    def _build_classpath(self, instance: dict, vjson: dict) -> str:
        cp = []
        # 版本 jar
        cp.append(str(self.vm.version_jar_path(instance["version"])))
        # 库文件
        from .compat import parse_library, name_to_path
        for raw in vjson.get("libraries", []):
            parsed = parse_library(raw)
            if parsed is None:
                continue
            _, path, url, sha1, size = parsed
            lib_path = self.config.libraries_dir / path
            if lib_path.exists():
                cp.append(str(lib_path))
        return os.pathsep.join(cp)

    # ---------- natives ----------
    def _natives_path(self, instance: dict, vjson: dict) -> str:
        return self._natives_path_for(instance["version"])

    def _natives_path_for(self, version_id: str) -> Path:
        return self.config.cache_dir / f"natives-{version_id}"
    def _asset_index_name(self, version_id: str) -> str:
        try:
            vjson = self.vm.get_version_json(version_id)
            return vjson.get("assetIndex", {}).get("id", "legacy")
        except Exception:
            return "legacy"
