"""版本管理：拉取版本清单、下载版本 JSON、库文件、资源对象。"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Callable, Optional

from .config import LauncherConfig
from .downloader import DownloadError, http_get_json, retry_download

# 进度回调：(已完成, 总数, 当前文件名)
TaskProgress = Callable[[int, int, str], None]


class VersionManager:
    """负责版本清单与版本文件的下载。"""

    def __init__(self, config: LauncherConfig):
        self.config = config
        self._manifest_cache: Optional[dict] = None

    # ---------- 版本清单 ----------
    def _manifest_path(self) -> Path:
        return self.config.cache_dir / "version_manifest_v2.json"

    def fetch_version_manifest(self, force: bool = False, timeout: float = 30.0) -> dict:
        """获取版本清单（内存缓存 + 磁盘缓存）。

        优先使用内存缓存；若磁盘有缓存则先用之，同时尝试网络刷新。
        网络失败时回退到磁盘缓存。
        """
        if self._manifest_cache and not force:
            return self._manifest_cache
        # 磁盘缓存
        disk = self._manifest_path()
        if disk.exists() and not force:
            try:
                data = json.loads(disk.read_text(encoding="utf-8"))
                self._manifest_cache = data
            except (json.JSONDecodeError, OSError):
                data = None
        else:
            data = None
        # 尝试网络刷新
        try:
            url = self.config.source_config["version_manifest"]
            fresh = http_get_json(url, timeout=timeout)
            self._manifest_cache = fresh
            disk.parent.mkdir(parents=True, exist_ok=True)
            disk.write_text(json.dumps(fresh, ensure_ascii=False), encoding="utf-8")
            return fresh
        except Exception:
            if data is not None:
                return data
            raise

    def list_versions(self, timeout: float = 30.0) -> list[dict]:
        """返回版本列表：[{id, type, url, time}]，release 在前。"""
        manifest = self.fetch_version_manifest(timeout=timeout)
        versions = manifest.get("versions", [])
        # release 优先，按时间排序
        order = {"release": 0, "snapshot": 1, "old_beta": 2, "old_alpha": 3}
        versions = sorted(
            versions,
            key=lambda v: (order.get(v.get("type"), 9), v.get("time", ""), v.get("id", "")),
        )
        return versions

    def latest_version_id(self) -> Optional[str]:
        manifest = self.fetch_version_manifest()
        latest = manifest.get("latest", {})
        return latest.get("release") or latest.get("snapshot")
    # ---------- 版本 JSON ----------
    def version_dir(self, version_id: str) -> Path:
        return self.config.versions_dir / version_id

    def version_json_path(self, version_id: str) -> Path:
        return self.version_dir(version_id) / f"{version_id}.json"

    def version_jar_path(self, version_id: str) -> Path:
        return self.version_dir(version_id) / f"{version_id}.jar"

    def get_version_json(self, version_id: str, fetch_if_missing: bool = True) -> dict:
        """读取本地版本 JSON；不存在则从清单 URL 拉取。"""
        path = self.version_json_path(version_id)
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
        if not fetch_if_missing:
            raise FileNotFoundError(f"版本 {version_id} 未下载")
        url = self._version_url(version_id)
        if not url:
            raise DownloadError(f"未找到版本 {version_id} 的下载地址")
        data = http_get_json(url)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        return data

    def _version_url(self, version_id: str) -> Optional[str]:
        for v in self.list_versions():
            if v.get("id") == version_id:
                return v.get("url")
        return None

    # ---------- 版本完整性检查 ----------
    def version_files_present(self, version_id: str) -> bool:
        """检查版本 jar 是否已下载。"""
        return self.version_jar_path(version_id).exists()

    # ---------- 下载完整版本 ----------
    def download_version(self, version_id: str,
                         progress: Optional[TaskProgress] = None) -> None:
        """下载版本 jar + 全部库文件 + 资源对象。

        若已下载完成则跳过（通过 sha1 判断）。
        """
        vjson = self.get_version_json(version_id)
        total_tasks = 1  # jar
        # 统计库文件
        total_tasks += len(self._libraries_needed(vjson))
        # 统计资源对象（客户端需要的）
        assets = self._asset_index(vjson)
        total_tasks += self._assets_needed_count(assets)
        done = 0

        def tick(name: str):
            nonlocal done
            done += 1
            if progress:
                progress(done, total_tasks, name)

        # 1. 版本 jar
        jar_url = vjson.get("downloads", {}).get("client", {}).get("url")
        jar_sha1 = vjson.get("downloads", {}).get("client", {}).get("sha1")
        if jar_url:
            jar_path = self.version_jar_path(version_id)
            retry_download(jar_url, jar_path, jar_sha1)
        tick(f"{version_id}.jar")

        # 2. 库文件
        for lib in self._libraries_needed(vjson):
            self._download_library(lib)
            tick(lib.name)

        # 3. natives（平台动态库，解压到 natives 目录）
        self._download_natives(version_id, vjson)
        tick("natives")

        # 4. 资源对象
        self._download_assets(assets)
        tick("assets")

    # ---------- natives ----------
    def natives_dir(self, version_id: str) -> Path:
        return self.config.cache_dir / f"natives-{version_id}"

    def _download_natives(self, version_id: str, vjson: dict) -> None:
        """下载并解压平台 native 库到 natives 目录。

        支持 LWJGL2（natives 字段）和 LWJGL3（name classifier）两种格式。
        """
        from .compat import native_download_info
        import zipfile
        import shutil

        natives_dir = self.natives_dir(version_id)
        natives_dir.mkdir(parents=True, exist_ok=True)
        base = self.config.source_config.get("library_base", "https://libraries.minecraft.net/")
        tmp_dir = self.config.cache_dir / "_native_dl"
        tmp_dir.mkdir(parents=True, exist_ok=True)

        errors = []
        for raw in vjson.get("libraries", []):
            info = native_download_info(raw, base)
            if not info:
                continue
            url, rel_path, sha1 = info
            dest = tmp_dir / Path(rel_path).name
            try:
                retry_download(url, dest, sha1)
            except DownloadError as e:
                errors.append(f"{rel_path}: {e}")
                continue
            try:
                with zipfile.ZipFile(dest) as zf:
                    for member in zf.namelist():
                        if member.startswith("META-INF/"):
                            continue
                        if member.endswith("/"):
                            continue
                        target = natives_dir / member
                        target.parent.mkdir(parents=True, exist_ok=True)
                        with zf.open(member) as src, open(target, "wb") as out:
                            shutil.copyfileobj(src, out)
            except Exception as e:
                errors.append(f"解压 {rel_path}: {e}")
                continue
        if errors:
            # 记录但不阻断（个别 native 失败不至于导致整个版本无法启动）
            try:
                (self.config.logs_dir / "native_errors.log").write_text(
                    "\n".join(errors), encoding="utf-8")
            except OSError:
                pass

    # ---------- 库文件 ----------
    class _Library:
        def __init__(self, name: str, path: str, url: str, sha1: Optional[str], size: int):
            self.name = name
            self.path = path  # 相对 libraries 目录的路径
            self.url = url
            self.sha1 = sha1
            self.size = size

    def _libraries_needed(self, vjson: dict) -> list["_Library"]:
        """解析 version JSON 中需要下载的库文件。"""
        from .compat import parse_library
        libs = []
        for raw in vjson.get("libraries", []):
            parsed = parse_library(raw)
            if parsed is None:
                continue
            libs.append(self._Library(*parsed))
        return libs

    def _download_library(self, lib: "_Library") -> None:
        dest = self.config.libraries_dir / lib.path
        if lib.sha1 and _sha1_matches(dest, lib.sha1):
            return
        # 优先使用下载源的库基址，回退到原始 url
        base = self.config.source_config.get("library_base")
        url = lib.url
        if base and lib.path.startswith("com/"):
            url = base + lib.path
        retry_download(url, dest, lib.sha1)

    # ---------- 资源对象 (assets) ----------
    def _asset_index(self, vjson: dict) -> Optional[dict]:
        assets_info = vjson.get("assetIndex", {})
        if not assets_info:
            return None
        index_path = self.config.resources_dir / "indexes" / (assets_info.get("id") + ".json")
        if index_path.exists():
            return json.loads(index_path.read_text(encoding="utf-8"))
        data = http_get_json(assets_info["url"])
        index_path.parent.mkdir(parents=True, exist_ok=True)
        index_path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        return data

    def _assets_needed_count(self, assets: Optional[dict]) -> int:
        if not assets:
            return 0
        objs = assets.get("objects", {})
        return sum(1 for k, v in objs.items() if not v.get("virtual"))

    def _download_assets(self, assets: Optional[dict]) -> None:
        if not assets:
            return
        base = self.config.source_config.get("resource_base", "https://resources.download.minecraft.net/")
        objs = assets.get("objects", {})
        for key, meta in objs.items():
            if meta.get("virtual"):
                continue
            h = meta.get("hash")
            if not h:
                continue
            dest = self.config.resources_dir / "objects" / h[:2] / h
            if dest.exists():
                continue
            url = base + h[:2] + "/" + h
            try:
                retry_download(url, dest, h)
            except DownloadError:
                # 单个资源失败不阻断整个流程
                continue


def _sha1_matches(path: Path, sha1: str) -> bool:
    from .downloader import sha1_hex
    try:
        return sha1_hex(path) == sha1
    except Exception:
        return False
