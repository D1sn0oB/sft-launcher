"""主窗口：侧边栏导航 + 页面切换。"""
from __future__ import annotations

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QStackedWidget, QButtonGroup,
)

from .theme import QSS
from .pages.home import HomePage
from .pages.versions import VersionsPage
from .pages.settings import SettingsPage
from core.app import App

NAV_ITEMS = [
    ("首页", "home"),
    ("版本下载", "versions"),
    ("下载中心", "mods"),
    ("设置", "settings"),
]


class MainWindow(QMainWindow):
    def __init__(self, app: App):
        super().__init__()
        self.app = app
        self.setWindowTitle("SFT 启动器")
        self.resize(1080, 720)
        self.setMinimumSize(900, 600)
        self.setStyleSheet(QSS)

        central = QWidget()
        central.setObjectName("root")
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # 侧边栏
        sidebar = QWidget()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(200)
        sb_lay = QVBoxLayout(sidebar)
        sb_lay.setContentsMargins(0, 0, 0, 0)
        sb_lay.setSpacing(4)
        title = QLabel("SFT 启动器")
        title.setObjectName("sidebar_title")
        sb_lay.addWidget(title)

        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)
        self.pages = QStackedWidget()
        self.nav_map = {}  # key -> button

        # 注册页面（模块内自建导航按钮）
        self._build_pages()

        for key in ("home", "versions", "mods", "settings"):
            btn = self.nav_map.get(key)
            if btn:
                sb_lay.addWidget(btn)
        sb_lay.addStretch()
        ver = QLabel("v0.1.0 · 测试版")
        ver.setObjectName("dim")
        ver.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sb_lay.addWidget(ver)

        root.addWidget(sidebar)
        root.addWidget(self.pages, 1)

        # 默认选中首页
        if self.nav_map:
            self.nav_map["home"].setChecked(True)

        self.statusBar().showMessage("就绪")

    def _build_pages(self):
        pages_defs = [
            (HomePage, "home", "首页"),
            (VersionsPage, "versions", "版本下载"),
            (ModsPageProxy, "mods", "下载中心"),
            (SettingsPage, "settings", "设置"),
        ]
        for cls, key, label in pages_defs:
            page = cls(self.app, self)
            self.pages.addWidget(page)
            btn = QPushButton(label)
            btn.setObjectName("nav_btn")
            btn.setCheckable(True)
            self.nav_group.addButton(btn)
            self.nav_map[key] = btn
            btn.clicked.connect(lambda _=False, k=key: self.switch_page(k))

    def switch_page(self, key):
        order = {"home": 0, "versions": 1, "mods": 2, "settings": 3}
        idx = order.get(key, 0)
        self.pages.setCurrentIndex(idx)
        # 高亮对应导航
        if key in self.nav_map:
            self.nav_map[key].setChecked(True)

    def notify(self, msg):
        self.statusBar().showMessage(msg, 5000)


# 下载中心页面（阶段 5 实现，先占位）
class ModsPageProxy(QWidget):
    def __init__(self, app: App, window):
        super().__init__()
        from .pages.mods import ModsPage
        # 直接复用真正的下载中心页面
        self._impl = ModsPage(app, window)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self._impl)
