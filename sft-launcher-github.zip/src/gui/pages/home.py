"""首页：多实例卡片列表 + 启动/新增/删除。"""
from __future__ import annotations

from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QScrollArea,
    QGridLayout, QLineEdit, QComboBox, QDialog, QMessageBox, QDialogButtonBox,
)

from ..widgets import Card, EmptyState
from .loader import LoaderInstallDialog
from ..theme import COLORS
from core.config import new_instance
from core.launcher import GameLaunchError
from core.auth import offline_auth


class HomePage(QWidget):
    def __init__(self, app, window):
        super().__init__()
        self.app = app
        self.window = window
        self._build()

    def _build(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.setSpacing(16)

        # 顶部：标题 + 操作按钮
        top = QHBoxLayout()
        left = QVBoxLayout()
        left.setSpacing(2)
        t = QLabel("我的实例")
        t.setObjectName("page_title")
        left.addWidget(t)
        sub = QLabel("创建和管理你的游戏实例")
        sub.setObjectName("page_subtitle")
        left.addWidget(sub)
        top.addLayout(left)
        top.addStretch()

        # 账号状态 + 登录按钮
        self.account_label = QLabel()
        self.account_label.setObjectName("dim")
        top.addWidget(self.account_label)
        self.login_btn = QPushButton()
        self.login_btn.setObjectName("ghost")
        self.login_btn.clicked.connect(self._toggle_login)
        top.addWidget(self.login_btn)

        add_btn = QPushButton("＋ 新建实例")
        add_btn.setObjectName("ghost")
        add_btn.clicked.connect(self._open_new_dialog)
        top.addWidget(add_btn)
        lay.addLayout(top)
        self._update_account_ui()

    def _update_account_ui(self):
        saved = self.app.auth.load_saved()
        if saved:
            self.account_label.setText(f"微软账号：{saved.get('username', '')}")
            self.login_btn.setText("退出登录")
        else:
            self.account_label.setText("未登录")
            self.login_btn.setText("微软登录")

    def _toggle_login(self):
        saved = self.app.auth.load_saved()
        if saved:
            ret = QMessageBox.question(self, "退出登录", "确定退出微软账号登录吗？")
            if ret == QMessageBox.StandardButton.Yes:
                self.app.auth.logout()
                self._update_account_ui()
                self.window.notify("已退出微软登录")
            return
        self._do_microsoft_login()

    def _do_microsoft_login(self):
        """微软设备码登录流程。"""
        try:
            dc = self.app.auth.request_device_code()
        except Exception as e:
            QMessageBox.warning(self, "登录失败", f"无法发起登录：{e}")
            return
        # 打开浏览器
        try:
            import webbrowser
            webbrowser.open(dc["verification_uri"])
        except Exception:
            pass
        # 显示设备码等待用户授权
        dlg = MsAuthDialog(self, dc, self.app.auth)
        dlg.exec()
        self._update_account_ui()
        self._refresh()

        # 实例卡片滚动区
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.cards_host = QWidget()
        self.cards_grid = QGridLayout(self.cards_host)
        self.cards_grid.setContentsMargins(0, 0, 8, 8)
        self.cards_grid.setSpacing(14)
        self.cards_grid.setAlignment(Qt.AlignmentFlag.AlignTop)
        scroll.setWidget(self.cards_host)
        lay.addWidget(scroll, 1)

        self._refresh()

    def refresh(self):
        self._refresh()

    def _refresh(self):
        # 清空网格
        while self.cards_grid.count():
            item = self.cards_grid.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

        instances = self.app.config.all_instances()
        if not instances:
            empty = EmptyState(
                icon="⛏",
                title="还没有实例",
                desc="点击右上角「新建实例」创建你的第一个游戏实例",
            )
            self.cards_grid.addWidget(empty, 0, 0)
            return

        versions = {}
        try:
            for v in self.app.versions.list_versions():
                versions[v["id"]] = v
        except Exception:
            pass

        for i, inst in enumerate(instances):
            card = self._make_instance_card(inst, versions)
            r, c = divmod(i, 2)
            self.cards_grid.addWidget(card, r, c)

    def _make_instance_card(self, inst, versions):
        card = Card()
        card.setObjectName("card")
        lay = QVBoxLayout(card)
        lay.setContentsMargins(18, 16, 18, 16)
        lay.setSpacing(8)

        # 名称 + 徽章
        top = QHBoxLayout()
        name = QLabel(inst["name"])
        name.setObjectName("card_title")
        top.addWidget(name)
        top.addStretch()
        ver_badge = QLabel(inst["version"])
        ver_badge.setObjectName("badge")
        top.addWidget(ver_badge)
        lay.addLayout(top)

        # 描述
        loader = inst.get("loader") or "原版"
        info = QLabel(f"加载器：{loader} · 内存：{inst.get('memory_mb', 2048)}MB")
        info.setObjectName("dim")
        lay.addWidget(info)

        # 按钮
        btns = QHBoxLayout()
        launch = QPushButton("启动游戏")
        launch.clicked.connect(lambda _=False, i=inst: self._launch(i))
        btns.addWidget(launch)
        loader_btn = QPushButton("安装加载器")
        loader_btn.setObjectName("ghost")
        loader_btn.clicked.connect(lambda _=False, i=inst: self._install_loader(i))
        btns.addWidget(loader_btn)
        btns.addStretch()
        del_btn = QPushButton("删除")
        del_btn.setObjectName("danger")
        del_btn.clicked.connect(lambda _=False, i=inst: self._delete(i))
        btns.addWidget(del_btn)
        lay.addLayout(btns)
        return card

    def _install_loader(self, inst):
        dlg = LoaderInstallDialog(self.app, self, inst)
        dlg.exec()
        self._refresh()

    # ---------- 新建实例 ----------
    def _open_new_dialog(self):
        dlg = NewInstanceDialog(self.app, self)
        dlg.exec()

    def _launch(self, inst):
        # 组装账号信息
        auth_type = inst.get("auth_type", "offline")
        if auth_type == "offline":
            auth = offline_auth(inst.get("username") or "Steve")
        else:
            # 微软账号：使用已保存的微软账号
            saved = self.app.auth.load_saved()
            if not saved:
                QMessageBox.information(
                    self, "需要登录",
                    "该实例设为微软登录，但尚未登录微软账号。\n"
                    "请先在首页点击「微软登录」完成登录后再启动。")
                return
            auth = saved
        try:
            self.window.notify(f"正在启动 {inst['name']} ...")
            proc = self.app.launcher.launch(inst, auth)
            self.window.notify(f"已启动 {inst['name']}（PID {proc.pid}）")
        except GameLaunchError as e:
            QMessageBox.warning(self, "启动失败", str(e))

    def _delete(self, inst):
        ret = QMessageBox.question(self, "删除实例",
                                   f"确定删除实例「{inst['name']}」吗？\n该实例的所有数据将被清除。")
        if ret == QMessageBox.StandardButton.Yes:
            self.app.config.remove_instance(inst["id"])
            self._refresh()


class MsAuthDialog(QDialog):
    """微软登录等待授权对话框（设备码流程）。"""
    def __init__(self, parent, device_code, auth_mgr):
        super().__init__(parent)
        self.auth_mgr = auth_mgr
        self.setWindowTitle("微软登录")
        self.setMinimumWidth(460)
        self.setModal(True)
        lay = QVBoxLayout(self)
        lay.setSpacing(10)

        t = QLabel("微软账号登录")
        t.setObjectName("page_title")
        lay.addWidget(t)

        d = QLabel("请在浏览器中打开授权页面，并输入下面的设备代码完成登录。")
        d.setObjectName("dim")
        d.setWordWrap(True)
        lay.addWidget(d)

        code = QLabel(device_code["user_code"])
        code.setStyleSheet(
            "font-size:28px;font-weight:bold;color:#4f8cff;"
            "background:#262a33;border-radius:8px;padding:16px;"
        )
        code.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(code)

        url = QLabel(device_code["verification_uri"])
        url.setObjectName("dim")
        url.setWordWrap(True)
        url.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        lay.addWidget(url)

        self.status = QLabel("等待授权...")
        self.status.setObjectName("dim")
        lay.addWidget(self.status)

        cancel = QPushButton("取消")
        cancel.setObjectName("ghost")
        cancel.clicked.connect(self.reject)
        lay.addWidget(cancel)

        # 后台轮询线程
        self._worker = MsPollWorker(self.auth_mgr, device_code)
        self._worker.done.connect(self._on_done)
        self._worker.error.connect(self._on_error)
        self._worker.start()

    def _on_done(self, account):
        self.status.setText(f"登录成功：{account.get('username', '')}")
        QTimer.singleShot(800, self.accept)

    def _on_error(self, msg):
        self.status.setText(f"失败：{msg}")


class MsPollWorker(QThread):
    """后台轮询微软授权状态。"""
    done = pyqtSignal(dict)
    error = pyqtSignal(str)

    def __init__(self, auth_mgr, device_code):
        super().__init__()
        self.auth_mgr = auth_mgr
        self.device_code = device_code

    def run(self):
        from core.auth import AuthError
        try:
            account = self.auth_mgr.login_device_flow(self.device_code)
            self.done.emit(account)
        except AuthError as e:
            self.error.emit(str(e))
        except Exception as e:
            self.error.emit(str(e))


class NewInstanceDialog(QDialog):
    """新建实例对话框。"""
    def __init__(self, app, parent):
        super().__init__(parent)
        self.app = app
        self.setWindowTitle("新建实例")
        self.setMinimumWidth(420)
        lay = QVBoxLayout(self)
        lay.setSpacing(12)

        lay.addWidget(self._field("实例名称"))
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("例如：我的生存服")
        lay.addWidget(self.name_edit)

        lay.addWidget(self._field("游戏版本"))
        self.version_combo = QComboBox()
        lay.addWidget(self.version_combo)
        self._load_versions()

        lay.addWidget(self._field("分配内存 (MB)"))
        self.mem_spin = _make_mem_spin()
        lay.addWidget(self.mem_spin)

        lay.addWidget(self._field("离线用户名"))
        self.user_edit = QLineEdit("Steve")
        lay.addWidget(self.user_edit)

        lay.addWidget(self._field("登录方式"))
        self.auth_combo = QComboBox()
        self.auth_combo.addItem("离线模式", "offline")
        self.auth_combo.addItem("微软账号", "microsoft")
        lay.addWidget(self.auth_combo)
        self.auth_combo.currentIndexChanged.connect(self._on_auth_change)

        btns = QDialogButtonBox()
        ok = btns.addButton("创建", QDialogButtonBox.ButtonRole.AcceptRole)
        cancel = btns.addButton("取消", QDialogButtonBox.ButtonRole.RejectRole)
        ok.clicked.connect(self._create)
        cancel.clicked.connect(self.reject)
        lay.addWidget(btns)

    def _field(self, text):
        l = QLabel(text)
        l.setObjectName("dim")
        return l

    def _load_versions(self):
        try:
            versions = self.app.versions.list_versions()
            for v in versions:
                if v["type"] in ("release", "snapshot"):
                    self.version_combo.addItem(f"{v['id']}  ({v['type']})", v["id"])
            # 默认选最新 release
            latest = self.app.versions.latest_version_id()
            idx = self.version_combo.findData(latest)
            if idx >= 0:
                self.version_combo.setCurrentIndex(idx)
        except Exception as e:
            self.version_combo.addItem("无法加载版本列表")
            self.warn = str(e)

    def _create(self):
        name = self.name_edit.text().strip() or "未命名实例"
        version_id = self.version_combo.currentData()
        if not version_id:
            QMessageBox.warning(self, "提示", "请选择一个游戏版本")
            return
        inst = new_instance(name, version_id, self.app.config.source)
        inst["memory_mb"] = self.mem_spin.value()
        inst["username"] = self.user_edit.text().strip() or "Steve"
        inst["auth_type"] = self.auth_combo.currentData() or "offline"
        inst["created"] = None
        self.app.config.add_instance(inst)
        self.app.config.instance_game_dir(inst["id"]).mkdir(parents=True, exist_ok=True)
        self.accept()
        # 刷新父页面
        parent = self.parent()
        if hasattr(parent, "refresh"):
            parent.refresh()

    def _on_auth_change(self, idx):
        # 离线模式下可编辑用户名，微软账号使用已登录账号
        self.user_edit.setEnabled(idx == 0)


def _make_mem_spin():
    from PyQt6.QtWidgets import QSpinBox
    s = QSpinBox()
    s.setRange(512, 16384)
    s.setSingleStep(512)
    s.setValue(2048)
    s.setSuffix(" MB")
    return s
