"""模组加载器安装对话框（Fabric / Forge）。"""
from __future__ import annotations

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QPushButton,
    QProgressBar, QMessageBox,
)


class LoaderInstallWorker(QThread):
    """后台安装加载器线程。"""
    progress = pyqtSignal(str)
    done = pyqtSignal(bool, str)

    def __init__(self, installer, kind, mcver, loader_ver):
        super().__init__()
        self.installer = installer
        self.kind = kind
        self.mcver = mcver
        self.loader_ver = loader_ver

    def run(self):
        try:
            if self.kind == "fabric":
                ver_id = self.installer.install(self.mcver, self.loader_ver,
                                                progress=lambda *a: self.progress.emit(a[0]))
            else:
                ver_id = self.installer.install(self.mcver, self.loader_ver,
                                                progress=lambda *a: self.progress.emit(a[0]))
            self.done.emit(True, ver_id)
        except Exception as e:
            self.done.emit(False, str(e))


class LoaderInstallDialog(QDialog):
    """选择加载器类型与版本并安装。"""

    def __init__(self, app, parent, inst):
        super().__init__(parent)
        self.app = app
        self.inst = inst
        self.setWindowTitle(f"安装模组加载器 - {inst['name']}")
        self.setMinimumWidth(460)
        lay = QVBoxLayout(self)
        lay.setSpacing(12)

        t = QLabel("模组加载器")
        t.setObjectName("page_title")
        lay.addWidget(t)

        d = QLabel(f"为实例「{inst['name']}」（MC {inst['version']}）安装模组加载器。\n"
                   "安装后可在启动器下载 Fabric/Forge 模组。")
        d.setObjectName("dim")
        d.setWordWrap(True)
        lay.addWidget(d)

        # 类型选择
        lay.addWidget(self._field("加载器类型"))
        self.kind_combo = QComboBox()
        self.kind_combo.addItem("Fabric", "fabric")
        self.kind_combo.addItem("Forge", "forge")
        self.kind_combo.currentIndexChanged.connect(self._load_versions)
        lay.addWidget(self.kind_combo)

        # 版本选择
        lay.addWidget(self._field("加载器版本"))
        self.version_combo = QComboBox()
        lay.addWidget(self.version_combo)

        # 进度
        self.bar = QProgressBar()
        self.bar.setVisible(False)
        self.bar.setRange(0, 0)  # 不确定进度
        lay.addWidget(self.bar)
        self.status = QLabel("")
        self.status.setObjectName("dim")
        self.status.setWordWrap(True)
        lay.addWidget(self.status)

        btns = QHBoxLayout()
        self.install_btn = QPushButton("安装")
        self.install_btn.clicked.connect(self._install)
        btns.addWidget(self.install_btn)
        self.cancel_btn = QPushButton("关闭")
        self.cancel_btn.setObjectName("ghost")
        self.cancel_btn.clicked.connect(self.reject)
        btns.addWidget(self.cancel_btn)
        lay.addLayout(btns)

        self._worker = None
        self._load_versions()

    def _field(self, text):
        l = QLabel(text)
        l.setObjectName("dim")
        return l

    def _load_versions(self):
        """根据类型加载版本列表。"""
        kind = self.kind_combo.currentData()
        self.version_combo.clear()
        self.version_combo.addItem("加载中...", None)
        self.install_btn.setEnabled(False)
        try:
            if kind == "fabric":
                from mods.fabric import FabricInstaller
                installer = FabricInstaller(self.app.config, self.app.versions)
                loaders = installer.list_loaders(self.inst["version"])
                self.version_combo.clear()
                for l in loaders[:40]:
                    label = l["loader_version"]
                    self.version_combo.addItem(label, l["loader_version"])
                self._fabric = installer
            else:
                from mods.forge import ForgeInstaller
                installer = ForgeInstaller(self.app.config, self.app.versions)
                vers = installer.list_versions(self.inst["version"])
                self.version_combo.clear()
                for v in vers[:40]:
                    self.version_combo.addItem(v["version_id"], v["forge_version"])
                self._forge = installer
        except Exception as e:
            self.version_combo.clear()
            self.version_combo.addItem(f"无法加载：{e}", None)
        self.install_btn.setEnabled(True)

    def _install(self):
        kind = self.kind_combo.currentData()
        ver = self.version_combo.currentData()
        if not ver:
            QMessageBox.warning(self, "提示", "请选择一个加载器版本")
            return
        installer = self._fabric if kind == "fabric" else self._forge
        self.install_btn.setEnabled(False)
        self.cancel_btn.setEnabled(False)
        self.bar.setVisible(True)
        self.status.setText("正在安装...")

        self._worker = LoaderInstallWorker(installer, kind, self.inst["version"], ver)
        self._worker.progress.connect(lambda s: self.status.setText(s))
        self._worker.done.connect(self._on_done)
        self._worker.start()

    def _on_done(self, ok, msg):
        self.bar.setVisible(False)
        self.install_btn.setEnabled(True)
        self.cancel_btn.setEnabled(True)
        if ok:
            # 更新实例的版本为加载器版本
            ver_id = msg
            self.app.config.update_instance(self.inst["id"], version=ver_id,
                                            loader=self.kind_combo.currentData())
            self.status.setText(f"安装成功：{ver_id}")
            QMessageBox.information(self, "安装成功",
                                    f"加载器已安装，版本：{ver_id}\n现在可以下载对应的模组了。")
            self.accept()
        else:
            self.status.setText(f"安装失败：{msg}")
            QMessageBox.warning(self, "安装失败", msg)
