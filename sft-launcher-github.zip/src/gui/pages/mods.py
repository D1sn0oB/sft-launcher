"""下载中心：搜索并下载 Mod / 资源包（Modrinth + CurseForge）。"""
from __future__ import annotations

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QScrollArea,
    QLineEdit, QComboBox, QProgressBar, QMessageBox,
)

from ..widgets import Card, EmptyState


class SearchWorker(QThread):
    """后台搜索线程。搜索结果附带来源平台。"""
    finished = pyqtSignal(list, str, str)  # results, error, platform_used

    def __init__(self, client, query, project_type, mc_ver, loader, platform):
        super().__init__()
        self.client = client
        self.query = query
        self.project_type = project_type
        self.mc_ver = mc_ver
        self.loader = loader
        self.platform = platform  # 目标平台

    def run(self):
        platform_used = self.platform
        try:
            if isinstance(self.client, ModrinthClient):
                results = self.client.search(self.query, project_type=self.project_type,
                                             mc_version=self.mc_ver or None,
                                             loader=self.loader or None)
                self.finished.emit(results, "", platform_used)
            else:
                # CurseForge
                pt = 6 if self.project_type == "mod" else 12
                try:
                    results = self.client.search(self.query, project_type=pt,
                                                 game_version=self.mc_ver or None)
                    self.finished.emit(results, "", "curseforge")
                except Exception as cf_err:
                    # CurseForge 失败/限流 → 自动降级到 Modrinth
                    self.finished.emit([], str(cf_err), "curseforge_failed")
        except Exception as e:
            self.finished.emit([], str(e), platform_used)


class DownloadFileWorker(QThread):
    """后台下载线程。"""
    progress = pyqtSignal(int, int)
    done = pyqtSignal(bool, str)

    def __init__(self, client, file, dest_dir):
        super().__init__()
        self.client = client
        self.file = file
        self.dest_dir = dest_dir

    def run(self):
        try:
            path = self.client.download_to(self.file, self.dest_dir,
                                           progress=self.progress.emit)
            self.done.emit(True, path)
        except Exception as e:
            self.done.emit(False, str(e))


from api.modrinth import ModrinthClient


class ModsPage(QWidget):
    def __init__(self, app, window):
        super().__init__()
        self.app = app
        self.window = window
        self._workers = []
        self._current_source = "Modrinth"
        self._build()
        self._load_instances()

    def _build(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.setSpacing(16)

        top = QHBoxLayout()
        left = QVBoxLayout()
        left.setSpacing(2)
        t = QLabel("下载中心")
        t.setObjectName("page_title")
        left.addWidget(t)
        sub = QLabel("从 Modrinth / CurseForge 下载 Mod 和资源包")
        sub.setObjectName("page_subtitle")
        left.addWidget(sub)
        top.addLayout(left)
        top.addStretch()
        lay.addLayout(top)

        # 筛选栏
        filter_row = QHBoxLayout()
        self.instance_combo = QComboBox()
        self.instance_combo.setMinimumWidth(160)
        self.instance_combo.setPlaceholderText("选择实例")
        filter_row.addWidget(self.instance_combo)
        self.type_combo = QComboBox()
        self.type_combo.addItem("Mod", "mod")
        self.type_combo.addItem("资源包", "resourcepack")
        filter_row.addWidget(self.type_combo)
        self.platform_combo = QComboBox()
        self.platform_combo.addItem("Modrinth", "modrinth")
        self.platform_combo.addItem("CurseForge", "curseforge")
        filter_row.addWidget(self.platform_combo)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("搜索 Mod / 资源包...")
        self.search_edit.returnPressed.connect(self._search)
        filter_row.addWidget(self.search_edit, 1)
        search_btn = QPushButton("搜索")
        search_btn.clicked.connect(self._search)
        filter_row.addWidget(search_btn)
        lay.addLayout(filter_row)

        # 提示
        hint = QLabel("提示：下载的 Mod 会保存到所选实例的 mods / resourcepacks 目录（版本分离）")
        hint.setObjectName("dim")
        lay.addWidget(hint)

        # 结果
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.results_host = QWidget()
        self.results_lay = QVBoxLayout(self.results_host)
        self.results_lay.setContentsMargins(0, 0, 8, 8)
        self.results_lay.setSpacing(10)
        self.results_lay.setAlignment(Qt.AlignmentFlag.AlignTop)
        scroll.setWidget(self.results_host)
        lay.addWidget(scroll, 1)

    def _load_instances(self):
        self.instance_combo.clear()
        self.instance_combo.addItem("（仅浏览，不安装）", None)
        for inst in self.app.config.all_instances():
            self.instance_combo.addItem(inst["name"], inst)

    def _current_instance(self):
        return self.instance_combo.currentData()

    def _client(self):
        platform = self.platform_combo.currentData()
        if platform == "modrinth":
            return ModrinthClient()
        else:
            from api.curseforge import CurseForgeClient
            key = self.app.config.get_setting("curseforge_key", "")
            return CurseForgeClient(key)

    def _search(self):
        query = self.search_edit.text().strip()
        if not query:
            return
        client = self._client()
        inst = self._current_instance()
        mc_ver = inst["version"] if inst else None
        loader = inst.get("loader") if inst else None
        project_type = self.type_combo.currentData()
        platform = self.platform_combo.currentData()
        from api.curseforge import CurseForgeClient
        if isinstance(client, CurseForgeClient) and not client.available:
            QMessageBox.information(
                self, "未配置 API Key",
                "CurseForge 需要 API Key。\n请在「设置」页填写 CurseForge API Key，\n或改用 Modrinth（无需配置）。")
            return
        worker = SearchWorker(client, query, project_type, mc_ver, loader, platform)
        worker.finished.connect(self._on_search_done)
        worker.start()
        self._workers.append(worker)
        self.window.notify(f"搜索：{query} ...")

    def _on_search_done(self, results, error, platform_used):
        # 清空结果
        while self.results_lay.count():
            item = self.results_lay.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

        # CurseForge 失败/限流 → 自动降级到 Modrinth
        if platform_used == "curseforge_failed":
            self.window.notify("CurseForge 暂不可用，已自动切换到 Modrinth")
            # 自动用 Modrinth 重新搜索
            client = ModrinthClient()
            inst = self._current_instance()
            mc_ver = inst["version"] if inst else None
            loader = inst.get("loader") if inst else None
            project_type = self.type_combo.currentData()
            query = self.search_edit.text().strip()
            worker = SearchWorker(client, query, project_type, mc_ver, loader, "modrinth")
            worker.finished.connect(self._on_search_done)
            worker.start()
            self._workers.append(worker)
            return

        if error:
            QMessageBox.warning(self, "搜索失败", error)
            return
        if not results:
            self.results_lay.addWidget(EmptyState(icon="🔍", title="没有找到结果",
                                                  desc="换个关键词或筛选条件试试"))
            return

        # 显示来源平台标识
        src_label = "Modrinth" if platform_used == "modrinth" else "CurseForge"
        if platform_used != "modrinth":
            pass
        self._current_source = src_label
        for r in results:
            self.results_lay.addWidget(self._result_card(r, src_label))

    def _result_card(self, result, source="Modrinth"):
        card = Card()
        lay = QVBoxLayout(card)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(6)

        top = QHBoxLayout()
        title = QLabel(result.get("title") or result.get("name") or "未知")
        title.setObjectName("card_title")
        top.addWidget(title)
        top.addStretch()
        src = QLabel(source)
        src.setObjectName("badge")
        if source == "CurseForge":
            src.setStyleSheet("background-color:rgba(224,163,78,0.18);color:#e0a34e;border-radius:4px;padding:2px 8px;font-size:11px;")
        top.addWidget(src)
        dl = QLabel(f"下载 {result.get('downloads', 0):,}")
        dl.setObjectName("badge")
        top.addWidget(dl)
        lay.addLayout(top)

        desc = (result.get("description") or result.get("summary") or "").strip()
        if desc:
            d = QLabel(desc[:120] + ("..." if len(desc) > 120 else ""))
            d.setObjectName("card_desc")
            d.setWordWrap(True)
            lay.addWidget(d)

        author = result.get("author") or result.get("slug") or ""
        if author:
            a = QLabel(f"作者：{author}")
            a.setObjectName("dim")
            lay.addWidget(a)

        # 下载按钮 + 进度
        btn_row = QHBoxLayout()
        install_btn = QPushButton("下载到实例")
        install_btn.clicked.connect(lambda _=False, r=result: self._download(r))
        btn_row.addWidget(install_btn)
        bar = QProgressBar()
        bar.setVisible(False)
        bar.setRange(0, 100)
        btn_row.addWidget(bar, 1)
        lay.addLayout(btn_row)
        # 存储进度条引用
        card._dl_bar = bar
        card._dl_btn = install_btn
        return card

    def _download(self, result):
        inst = self._current_instance()
        if not inst:
            QMessageBox.information(self, "提示", "请先在上方选择目标实例")
            return
        # 根据结果来源平台选择客户端（兼容降级场景）
        source = getattr(self, "_current_source", "Modrinth")
        if source == "CurseForge":
            from api.curseforge import CurseForgeClient
            client = CurseForgeClient(self.app.config.get_setting("curseforge_key", ""))
        else:
            client = ModrinthClient()
        project_type = self.type_combo.currentData()
        mc_ver = inst["version"]
        loader = inst.get("loader")
        # 解析版本并选文件
        try:
            if isinstance(client, ModrinthClient):
                file = client.pick_best_file(result["slug"], mc_ver, loader)
            else:
                file = client.pick_best_file(result["id"], mc_ver)
        except Exception as e:
            QMessageBox.warning(self, "获取版本失败", str(e))
            return
        if not file:
            QMessageBox.information(self, "无可用版本",
                                    f"该内容没有适配 MC {mc_ver} 的版本。")
            return
        # 目标目录（版本分离）
        game_dir = self.app.config.instance_game_dir(inst["id"])
        dest_dir = game_dir / ("mods" if project_type == "mod" else "resourcepacks")
        dest_dir.mkdir(parents=True, exist_ok=True)
        # 下载
        worker = DownloadFileWorker(client, file, dest_dir)
        worker.progress.connect(self._on_dl_progress)
        worker.done.connect(self._on_dl_done)
        worker.start()
        self._workers.append(worker)
        self.window.notify(f"正在下载 {file['filename']} ...")

    def _on_dl_progress(self, done, total):
        # 简化：状态栏显示
        pass

    def _on_dl_done(self, ok, msg):
        if ok:
            self.window.notify("下载完成：" + msg)
            QMessageBox.information(self, "下载完成", f"已保存到：\n{msg}")
        else:
            QMessageBox.warning(self, "下载失败", msg)
