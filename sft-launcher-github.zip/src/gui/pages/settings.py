"""设置页面：下载源切换、Java 选择、外观等。"""
from __future__ import annotations

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QComboBox, QPushButton,
    QFileDialog, QMessageBox, QGroupBox,
)

from ..theme import COLORS
from core.config import SOURCES
from core.java_manager import java_major_version


class SettingsPage(QWidget):
    def __init__(self, app, window):
        super().__init__()
        self.app = app
        self.window = window
        self._build()

    def _build(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.setSpacing(16)

        t = QLabel("设置")
        t.setObjectName("page_title")
        lay.addWidget(t)
        sub = QLabel("启动器全局配置")
        sub.setObjectName("page_subtitle")
        lay.addWidget(sub)

        # 下载源
        src_box = QGroupBox("下载源")
        src_lay = QVBoxLayout(src_box)
        src_h = QHBoxLayout()
        self.src_combo = QComboBox()
        for key, info in SOURCES.items():
            self.src_combo.addItem(info["label"], key)
        cur = self.app.config.source
        idx = self.src_combo.findData(cur)
        if idx >= 0:
            self.src_combo.setCurrentIndex(idx)
        self.src_combo.currentIndexChanged.connect(self._on_source_change)
        src_h.addWidget(self.src_combo, 1)
        src_h.addStretch()
        src_lay.addLayout(src_h)
        src_note = QLabel("国内网络建议使用 BMCLAPI 镜像，速度更快。")
        src_note.setObjectName("dim")
        src_lay.addWidget(src_note)
        lay.addWidget(src_box)

        # Java
        java_box = QGroupBox("Java 运行时")
        java_lay = QVBoxLayout(java_box)
        java_row = QHBoxLayout()
        self.java_label = QLabel("未检测到 Java")
        self.java_label.setWordWrap(True)
        java_row.addWidget(self.java_label, 1)
        detect_btn = QPushButton("重新检测")
        detect_btn.setObjectName("ghost")
        detect_btn.clicked.connect(self._detect_java)
        java_row.addWidget(detect_btn)
        manual_btn = QPushButton("手动选择")
        manual_btn.setObjectName("ghost")
        manual_btn.clicked.connect(self._pick_java)
        java_row.addWidget(manual_btn)
        java_lay.addLayout(java_row)
        java_note = QLabel("启动器会根据游戏版本自动选择对应 Java 版本。")
        java_note.setObjectName("dim")
        java_lay.addWidget(java_note)
        lay.addWidget(java_box)

        # CurseForge API Key
        cf_box = QGroupBox("CurseForge API Key")
        cf_lay = QVBoxLayout(cf_box)
        from PyQt6.QtWidgets import QLineEdit
        self.cf_key_edit = QLineEdit()
        self.cf_key_edit.setPlaceholderText("填入 CurseForge API Key 以启用下载中心（可选）")
        self.cf_key_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.cf_key_edit.setText(self.app.config.get_setting("curseforge_key", ""))
        self.cf_key_edit.editingFinished.connect(self._save_cf_key)
        cf_lay.addWidget(self.cf_key_edit)
        cf_note = QLabel("没有 Key 也能用 Modrinth 下载。获取方式见 docs/curseforge-api.md。")
        cf_note.setObjectName("dim")
        cf_note.setWordWrap(True)
        cf_lay.addWidget(cf_note)
        lay.addWidget(cf_box)

        # 关于
        about_box = QGroupBox("关于")
        about_lay = QVBoxLayout(about_box)
        about = QLabel(
            "SFT 启动器 v0.1.0（测试版）\n"
            "功能：多实例 · 版本下载 · 离线/微软登录 · 模组加载器 · Mod 下载\n"
            "本软件为开源工具，与 Mojang 无关。")
        about.setWordWrap(True)
        about_lay.addWidget(about)
        lay.addWidget(about_box)

        lay.addStretch()
        self._detect_java()

    def _save_cf_key(self):
        self.app.config.set_setting("curseforge_key", self.cf_key_edit.text().strip())
        self.window.notify("CurseForge API Key 已保存")

    def _on_source_change(self, idx):
        key = self.src_combo.itemData(idx)
        if key:
            self.app.config.set_setting("source", key)
            self.window.notify(f"下载源已切换为 {SOURCES[key]['label']}")

    def _detect_java(self):
        java = self.app.java.find_java()
        if java:
            ver = java_major_version(java)
            self.java_label.setText(f"已找到 Java {ver}：{java}")
            self.window.notify("Java 检测完成")
        else:
            self.java_label.setText("未检测到 Java，可在设置中手动指定路径。")
            self.java_label.setStyleSheet("color:#e0a34e;")

    def _pick_java(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "选择 java 可执行文件",
            "", "Java 可执行文件 (java.exe java)")
        if path:
            ver = java_major_version(path)
            if ver is None:
                QMessageBox.warning(self, "无效", "所选文件不是有效的 Java 可执行文件")
                return
            self.app.config.set_setting("java_path", path)
            self.java_label.setText(f"已指定 Java {ver}：{path}")
            self.window.notify("Java 路径已保存")
