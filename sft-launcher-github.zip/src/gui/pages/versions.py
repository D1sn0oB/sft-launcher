"""版本下载页面：浏览版本、下载版本、查看进度。"""
from __future__ import annotations

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QScrollArea,
    QGridLayout, QLineEdit, QMessageBox,
)

from ..widgets import Card, EmptyState
from core.downloader import DownloadError


class DownloadWorker(QThread):
    """后台下载线程。"""
    progress = pyqtSignal(int, int, str)
    done = pyqtSignal(bool, str)

    def __init__(self, app, version_id):
        super().__init__()
        self.app = app
        self.version_id = version_id

    def run(self):
        try:
            self.app.versions.download_version(
                self.version_id, progress=self.progress.emit)
            self.done.emit(True, "下载完成")
        except DownloadError as e:
            self.done.emit(False, str(e))
        except Exception as e:
            self.done.emit(False, f"未知错误: {e}")


class VersionsPage(QWidget):
    def __init__(self, app, window):
        super().__init__()
        self.app = app
        self.window = window
        self.versions_cache = []
        self.workers = {}
        self._progress_bars = {}
        self._list_worker = None
        self._build()
        self.refresh_async()

    def refresh_async(self):
        """后台加载版本列表，避免阻塞 UI。"""
        if self._list_worker and self._list_worker.isRunning():
            return
        from ..widgets import VersionListWorker
        self._list_worker = VersionListWorker(self.app)
        self._list_worker.finished.connect(self._on_list_loaded)
        self._list_worker.start()

    def _build(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 24, 28, 24)
        lay.setSpacing(16)

        top = QHBoxLayout()
        left = QVBoxLayout()
        left.setSpacing(2)
        t = QLabel("版本下载")
        t.setObjectName("page_title")
        left.addWidget(t)
        sub = QLabel(f"当前源：{self.app.config.source_config['label']}")
        sub.setObjectName("page_subtitle")
        left.addWidget(sub)
        top.addLayout(left)
        top.addStretch()
        refresh_btn = QPushButton("刷新列表")
        refresh_btn.setObjectName("ghost")
        refresh_btn.clicked.connect(self.refresh)
        top.addWidget(refresh_btn)
        lay.addLayout(top)

        # 搜索框
        self.search = QLineEdit()
        self.search.setPlaceholderText("搜索版本...")
        self.search.textChanged.connect(self._render)
        lay.addWidget(self.search)

        # 列表
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.host = QWidget()
        self.grid = QGridLayout(self.host)
        self.grid.setContentsMargins(0, 0, 8, 8)
        self.grid.setSpacing(10)
        self.grid.setAlignment(Qt.AlignmentFlag.AlignTop)
        scroll.setWidget(self.host)
        lay.addWidget(scroll, 1)

    def refresh(self):
        """手动刷新入口。"""
        self.refresh_async()

    def _on_list_loaded(self, versions, error):
        if error:
            QMessageBox.warning(self, "加载失败", error)
        self.versions_cache = versions or []
        self._render()

    def _render(self):
        while self.grid.count():
            item = self.grid.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

        query = self.search.text().strip().lower()
        versions = [v for v in self.versions_cache if query in v["id"].lower()]
        if not versions:
            self.grid.addWidget(EmptyState(icon="⬇", title="没有找到版本", desc="换个关键词试试"), 0, 0)
            return

        for i, v in enumerate(versions):
            r, c = divmod(i, 2)
            self.grid.addWidget(self._version_card(v), r, c)

    def _version_card(self, v):
        v_id = v["id"]
        card = Card()
        lay = QVBoxLayout(card)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(8)

        top = QHBoxLayout()
        name = QLabel(v_id)
        name.setObjectName("card_title")
        top.addWidget(name)
        top.addStretch()
        badge = QLabel(v["type"])
        badge.setObjectName("badge")
        top.addWidget(badge)
        lay.addLayout(top)

        # 下载状态
        downloaded = self.app.versions.version_files_present(v_id)
        status = QLabel("已下载" if downloaded else f"发布于 {v.get('time', '')[:10]}")
        status.setObjectName("dim")
        lay.addWidget(status)

        # 进度条（若有）
        if v_id in self.workers:
            from PyQt6.QtWidgets import QProgressBar
            bar = QProgressBar()
            bar.setObjectName("dlbar")
            bar.setRange(0, 100)
            bar.setValue(0)
            lay.addWidget(bar)
            self._progress_bars[v_id] = bar

        btn_row = QHBoxLayout()
        if downloaded:
            btn = QPushButton("重新下载")
            btn.setObjectName("ghost")
        else:
            btn = QPushButton("下载")
        btn.clicked.connect(lambda _=False, vid=v_id: self._start_download(vid))
        btn_row.addWidget(btn)
        btn_row.addStretch()
        lay.addLayout(btn_row)
        return card

    def _start_download(self, v_id):
        if v_id in self.workers:
            return
        worker = DownloadWorker(self.app, v_id)
        worker.progress.connect(lambda d, t, name: self._on_progress(v_id, d, t, name))
        worker.done.connect(lambda ok, msg: self._on_done(v_id, ok, msg))
        self.workers[v_id] = worker
        worker.start()
        self.window.notify(f"开始下载 {v_id} ...")
        self._render()

    def _on_progress(self, v_id, done, total, name):
        bar = getattr(self, "_progress_bars", {}).get(v_id)
        if bar:
            pct = int(done * 100 / total) if total else 0
            bar.setValue(pct)
            bar.setFormat(f"{pct}% · {name}")
        self.window.notify(f"下载中：{name}")

    def _on_done(self, v_id, ok, msg):
        self.workers.pop(v_id, None)
        if ok:
            self.window.notify(f"{v_id} {msg}")
        else:
            QMessageBox.warning(self, "下载失败", f"{v_id}: {msg}")
        self._render()
