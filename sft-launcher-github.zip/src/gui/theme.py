"""全局样式（QSS）：现代深色卡片风格。"""
from __future__ import annotations

# 主题色板
COLORS = {
    "bg": "#1e2128",
    "bg_alt": "#262a33",
    "card": "#2b2f3a",
    "card_hover": "#333846",
    "border": "#3a3f4e",
    "text": "#e8eaef",
    "text_dim": "#9aa0af",
    "accent": "#4f8cff",
    "accent_hover": "#6b9dff",
    "accent_press": "#3f74d6",
    "success": "#4caf7d",
    "danger": "#e05b5b",
    "warning": "#e0a34e",
}

QSS = f"""
* {{
    font-family: "Microsoft YaHei", "PingFang SC", "Segoe UI", sans-serif;
    font-size: 13px;
    color: {COLORS['text']};
}}
QMainWindow, QWidget#root {{
    background-color: {COLORS['bg']};
}}
/* 侧边栏 */
QWidget#sidebar {{
    background-color: {COLORS['bg_alt']};
    border-right: 1px solid {COLORS['border']};
}}
QLabel#sidebar_title {{
    color: {COLORS['accent']};
    font-size: 17px;
    font-weight: bold;
    padding: 20px 16px 12px 20px;
}}
QPushButton#nav_btn {{
    background: transparent;
    border: none;
    text-align: left;
    padding: 12px 20px;
    font-size: 14px;
    color: {COLORS['text_dim']};
    border-radius: 0;
}}
QPushButton#nav_btn:hover {{
    background: {COLORS['card']};
    color: {COLORS['text']};
}}
QPushButton#nav_btn:checked {{
    background: {COLORS['card_hover']};
    color: {COLORS['accent']};
    border-left: 3px solid {COLORS['accent']};
}}
/* 内容区 */
QWidget#content {{
    background-color: {COLORS['bg']};
}}
QLabel#page_title {{
    font-size: 22px;
    font-weight: bold;
    color: {COLORS['text']};
}}
QLabel#page_subtitle {{
    color: {COLORS['text_dim']};
    font-size: 13px;
}}
/* 卡片 */
QFrame#card {{
    background-color: {COLORS['card']};
    border: 1px solid {COLORS['border']};
    border-radius: 10px;
}}
QFrame#card:hover {{
    background-color: {COLORS['card_hover']};
}}
QLabel#card_title {{
    font-size: 15px;
    font-weight: bold;
}}
QLabel#card_desc {{
    color: {COLORS['text_dim']};
}}
QLabel#badge {{
    background-color: rgba(79,140,255,0.15);
    color: {COLORS['accent']};
    border-radius: 4px;
    padding: 2px 8px;
    font-size: 11px;
}}
/* 按钮 */
QPushButton {{
    background-color: {COLORS['accent']};
    color: white;
    border: none;
    border-radius: 6px;
    padding: 8px 18px;
    font-size: 13px;
}}
QPushButton:hover {{ background-color: {COLORS['accent_hover']}; }}
QPushButton:pressed {{ background-color: {COLORS['accent_press']}; }}
QPushButton#ghost {{
    background-color: transparent;
    border: 1px solid {COLORS['border']};
    color: {COLORS['text']};
}}
QPushButton#ghost:hover {{ background-color: {COLORS['card_hover']}; border-color: {COLORS['accent']}; }}
QPushButton#danger {{
    background-color: transparent;
    border: 1px solid {COLORS['danger']};
    color: {COLORS['danger']};
}}
QPushButton#danger:hover {{ background-color: rgba(224,91,91,0.1); }}
/* 输入框 */
QLineEdit, QComboBox, QSpinBox {{
    background-color: {COLORS['bg']};
    border: 1px solid {COLORS['border']};
    border-radius: 6px;
    padding: 8px 10px;
    color: {COLORS['text']};
}}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus {{
    border-color: {COLORS['accent']};
}}
QComboBox::drop-down {{
    border: none;
    width: 20px;
}}
/* 滚动区 */
QScrollArea {{ background: transparent; border: none; }}
QScrollArea > QWidget > QWidget {{ background: transparent; }}
QAbstractScrollArea::viewport {{ background: transparent; }}
QScrollBar:vertical {{
    background: transparent; width: 8px; margin: 0;
}}
QScrollBar::handle:vertical {{
    background: {COLORS['border']}; border-radius: 4px; min-height: 30px;
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
/* 进度条 */
QProgressBar {{
    background-color: {COLORS['bg']};
    border: none;
    border-radius: 5px;
    height: 10px;
    text-align: center;
}}
QProgressBar::chunk {{
    background-color: {COLORS['accent']};
    border-radius: 5px;
}}
/* 状态栏 */
QStatusBar {{ background: {COLORS['bg_alt']}; color: {COLORS['text_dim']}; }}
/* 分割线 */
QFrame#hsep {{ background: {COLORS['border']}; max-height: 1px; }}
QLabel#dim {{ color: {COLORS['text_dim']}; }}
QLabel#empty_icon {{ color: {COLORS['border']}; font-size: 48px; }}
QCheckBox {{ color: {COLORS['text']}; }}
"""
