"""可复用 UI 组件：卡片、空状态、标题栏等。"""
from __future__ import annotations

from PyQt6.QtCore import Qt, pyqtSignal, QThread
from PyQt6.QtWidgets import (
    QFrame, QLabel, QVBoxLayout, QHBoxLayout, QPushButton, QWidget,
)


class VersionListWorker(QThread):
    """后台加载版本清单（带磁盘缓存回退，不阻塞 UI）。"""
    finished = pyqtSignal(list, str)

    def __init__(self, app):
        super().__init__()
        self.app = app

    def run(self):
        try:
            versions = self.app.versions.list_versions(timeout=8.0)
            self.finished.emit(versions, "")
        except Exception as e:
            self.finished.emit([], f"无法加载版本列表：{e}")


def make_card() -> QFrame:
    """创建一个标准卡片容器。"""
    card = QFrame()
    card.setObjectName("card")
    return card


class Card(QFrame):
    """可点击的卡片容器，无内置布局，由调用方自行填充。"""
    clicked = pyqtSignal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("card")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._data = None

    def set_data(self, data):
        self._data = data

    def data(self):
        return self._data

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self)
        super().mousePressEvent(e)


class EmptyState(QWidget):
    """空状态提示。"""
    def __init__(self, icon="▢", title="暂无内容", desc="", parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ic = QLabel(icon)
        ic.setObjectName("empty_icon")
        ic.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(ic)
        t = QLabel(title)
        t.setObjectName("page_title")
        t.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(t)
        if desc:
            d = QLabel(desc)
            d.setObjectName("dim")
            d.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lay.addWidget(d)
