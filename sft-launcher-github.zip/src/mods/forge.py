"""Forge 模组加载器安装。

Forge 提供官方版本 JSON（含完整库清单），直接下载使用。
版本 ID 形如 <mcver>-<forgever>。
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from core.downloader import DownloadError, http_get_json, retry_download
from core.config import LauncherConfig
from core.version import VersionManager

FORGE_MANIFEST = "https://files.minecraftforge.net/net/minecraftforge/forge/maven-metadata.json"
FORGE_MAVEN = "https://maven.minecraftforge.net/net/minecraftforge/forge/{version}/forge-{version}.json"
# BMCLAPI 镜像
BMCLAPI_FORGE_LIST = "https://bmclapi2.bangbang93.com/forge/minecraft/{mcver}"


class ForgeError(Exception):
    pass


class ForgeInstaller:
    """Forge 加载器安装器。"""

    def __init__(self, config: LauncherConfig, version_manager: VersionManager):
        self.config = config
        self.vm = version_manager

    # ---------- 版本列表 ----------
    def list_versions(self, mcver: str) -> list[dict]:
        """获取指定 MC 版本可用的 Forge 版本列表（含下载 URL）。"""
        url = BMCLAPI_FORGE_LIST.format(mcver=mcver)
        try:
            data = http_get_json(url, timeout=15)
        except DownloadError:
            # 回退官方 manifest
            try:
                data = self._official_versions(mcver)
            except DownloadError as e:
                raise ForgeError(f"无法获取 Forge 版本：{e}")
        result = []
        for item in data:
            ver = item.get("version", "")
            result.append({
                "forge_version": ver,
                "version_id": f"{mcver}-{ver}",
                "build": item.get("build"),
            })
        # 按 build 降序
        result.sort(key=lambda x: x.get("build") or 0, reverse=True)
        return result

    def _official_versions(self, mcver: str) -> list:
        try:
            data = http_get_json(FORGE_MANIFEST, timeout=15)
        except DownloadError:
            return []
        mc_entries = data.get(mcver, [])
        out = []
        for e in mc_entries:
            out.append({"version": e.get("version"), "build": e.get("build", 0)})
        return out

    def latest_version(self, mcver: str) -> Optional[dict]:
        versions = self.list_versions(mcver)
        return versions[0] if versions else None

    # ---------- 安装 ----------
    def install(self, mcver: str, forge_version: Optional[str] = None,
                progress=None) -> str:
        """安装 Forge 到指定 MC 版本。返回 Forge 版本 ID。"""
        ver = self.latest_version(mcver) if not forge_version else \
            next((v for v in self.list_versions(mcver) if v["forge_version"] == forge_version), None)
        if not ver:
            raise ForgeError(f"未找到 Forge 版本 {forge_version}")
        version_id = ver["version_id"]

        if progress:
            progress(f"获取 Forge {version_id} 版本信息", 0, 1)
        vjson = self._fetch_version_json(version_id, ver["forge_version"])

        if progress:
            progress("写入版本 JSON", 0, 2)
        ver_dir = self.config.versions_dir / version_id
        ver_dir.mkdir(parents=True, exist_ok=True)
        (ver_dir / f"{version_id}.json").write_text(
            json.dumps(vjson, ensure_ascii=False, indent=2), encoding="utf-8")

        if progress:
            progress("复制原版 jar", 0, 3)
        base_jar = self.vm.version_jar_path(mcver)
        if base_jar.exists():
            import shutil
            shutil.copy2(base_jar, ver_dir / f"{version_id}.jar")

        if progress:
            progress("完成", 1, 1)
        return version_id

    def _fetch_version_json(self, version_id: str, forge_version: str) -> dict:
        """获取 Forge 官方版本 JSON，多源回退。"""
        urls = [
            # BMCLAPI 镜像
            f"https://bmclapi2.bangbang93.com/version/{version_id}/json",
            f"https://bmclapi2.bangbang93.com/maven/net/minecraftforge/forge/{version_id}/forge-{version_id}.json",
            # 官方 maven
            f"https://maven.minecraftforge.net/net/minecraftforge/forge/{version_id}/forge-{version_id}.json",
            # MCBBS 镜像
            f"https://download.mcbbs.net/maven/net/minecraftforge/forge/{version_id}/forge-{version_id}.json",
        ]
        for url in urls:
            try:
                return http_get_json(url, timeout=20)
            except DownloadError:
                continue
        raise ForgeError(f"无法获取 Forge {version_id} 的版本 JSON（请检查网络或更换下载源）")
